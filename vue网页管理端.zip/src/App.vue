<template>
  <router-view/>
</template>

<style>
html,body,#app{
  height: 100%;
}
</style>
