<template>
  <div class="footer">
    Copyright © 2022-2023 Touko 版权所有&nbsp;&nbsp;<a
      href="https://space.bilibili.com/177004534?spm_id_from=333.1007.0.0"
      target="_blank"
      >联系站长</a
    >
  </div>
</template>

<script></script>

<style lang="scss" scoped>
.footer {
  padding: 20px;
  display: flex;
  align-items: center;
}
</style>
