<template>
  <div class="home">欢迎使用，Touko音乐商城后台管理</div>
</template>

<script>
export default {
  name: "index",
};
</script>

<style lang="scss" scoped>
.home {
  padding: 40px;
  font-size: 30px;
  font-weight: bold;
}
</style>
