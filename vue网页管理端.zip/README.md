# Touko_mall

## Project setup

编译器里直接打：

```
yarn
```

### Compiles and hot-reloads for development

打包好后运行项目：

```
yarn serve
```
