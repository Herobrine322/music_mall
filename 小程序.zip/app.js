// app.js
App({
  onLaunch() {
   
  },
  globalData: {
    index:-1
  }
})
