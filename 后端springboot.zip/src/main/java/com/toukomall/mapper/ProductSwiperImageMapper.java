package com.toukomall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.toukomall.entity.ProductSwiperImage;

/**
 * 产品轮播图片Mapper接口
 */
public interface ProductSwiperImageMapper extends BaseMapper<ProductSwiperImage> {
}
