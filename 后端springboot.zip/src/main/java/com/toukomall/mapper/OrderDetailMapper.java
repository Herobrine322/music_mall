package com.toukomall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.toukomall.entity.OrderDetail;

/**
 * 订单详情Mapper接口
 */
public interface OrderDetailMapper extends BaseMapper<OrderDetail> {
}
