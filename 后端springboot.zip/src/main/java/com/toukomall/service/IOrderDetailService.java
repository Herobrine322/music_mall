package com.toukomall.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.toukomall.entity.OrderDetail;

/**
 * 订单详情Service接口
 */
public interface IOrderDetailService extends IService<OrderDetail> {
}
