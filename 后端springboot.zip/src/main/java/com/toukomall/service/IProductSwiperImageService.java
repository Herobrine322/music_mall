package com.toukomall.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.toukomall.entity.ProductSwiperImage;

/**
 * 产品轮播图片Service接口
 */
public interface IProductSwiperImageService extends IService<ProductSwiperImage> {
}
