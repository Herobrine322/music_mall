package com.toukomall.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.toukomall.entity.WxUserInfo;

/**
 * 微信用户Service接口
 */
public interface IWxUserInfoService extends IService<WxUserInfo> {
}
