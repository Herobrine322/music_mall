package com.toukomall.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.toukomall.entity.BigType;

/**
 * 商品大类Service接口
 */
public interface IBigTypeService extends IService<BigType> {
}
