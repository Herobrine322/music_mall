package com.toukomall.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.toukomall.entity.WxUserInfo;
import com.toukomall.mapper.WxUserInfoMapper;
import com.toukomall.service.IWxUserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 微信用户Service实现类
 */
@Service("wxUserInfoService")
public class IWxUserInfoServiceImpl extends ServiceImpl<WxUserInfoMapper,WxUserInfo> implements IWxUserInfoService {

    @Autowired
    private WxUserInfoMapper wxUserInfoMapper;
}
