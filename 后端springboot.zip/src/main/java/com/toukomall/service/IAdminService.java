package com.toukomall.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.toukomall.entity.Admin;

/**
 * 管理员Service接口
 */
public interface IAdminService extends IService<Admin> {
}
